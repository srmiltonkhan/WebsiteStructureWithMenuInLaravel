@extends('layout.app')
@section('title','About')
@section('content')

<h1>About Pate</h1>
@endsection