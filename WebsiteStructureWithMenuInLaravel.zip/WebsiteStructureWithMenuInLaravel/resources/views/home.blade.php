@extends('layout.app')
@section('title','Home')

@section('content')
<h1>Home Pate</h1>
@endsection