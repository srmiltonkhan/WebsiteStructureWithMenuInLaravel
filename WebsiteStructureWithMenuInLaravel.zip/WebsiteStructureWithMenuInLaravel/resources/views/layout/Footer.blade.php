<div class="p-2 bg-info">
  <h5 class="text-center">All Right Reserved By Milton Khan</h5>
</div>