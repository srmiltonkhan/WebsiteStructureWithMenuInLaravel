@extends('layout.app')
@section('title','Portfolio')

@section('content')
<h1>Portfolio Pate</h1>
@endsection