@extends('layout.app')
@section('title','Service')

@section('content')
   <h1>Service</h1>
@endsection