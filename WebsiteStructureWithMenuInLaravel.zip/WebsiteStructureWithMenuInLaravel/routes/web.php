<?php

use Illuminate\Support\Facades\Route;

Route::group(['namespace'=>'App\Http\Controllers'],function(){
    Route::get('/', 'SiteController@showHome');
    Route::get('/about', 'SiteController@showAbout');
    Route::get('/service', 'SiteController@showService');
    Route::get('/portfolio', 'SiteController@showPortfolio');
});
