<ul>
    <li>Home</li>
    <li>Course Plan</li>
    <li>Free Class</li>
    <li>Class Room</li>
</ul><?php /**PATH C:\Users\Administrator\Desktop\Laravel Project\kyamch\resources\views/subview/Menu.blade.php ENDPATH**/ ?>