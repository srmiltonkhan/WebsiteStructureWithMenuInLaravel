<h1>First Name: <?php echo e($FirstKey); ?></h1><br>
<h1>Middle Name: <?php echo e($MiddleKey); ?></h1><br>
<h1>Last Name: <?php echo e($LastName); ?></h1><?php /**PATH C:\Users\Administrator\Desktop\Laravel Project\kyamch\resources\views/DemoView.blade.php ENDPATH**/ ?>