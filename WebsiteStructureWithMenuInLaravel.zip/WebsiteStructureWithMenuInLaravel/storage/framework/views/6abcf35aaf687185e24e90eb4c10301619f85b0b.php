<div class="p-2 bg-info">
  <h5 class="text-center">All Right Reserved By Milton Khan</h5>
</div><?php /**PATH C:\Users\Administrator\Desktop\Laravel Project\kyamch\resources\views/layout/Footer.blade.php ENDPATH**/ ?>