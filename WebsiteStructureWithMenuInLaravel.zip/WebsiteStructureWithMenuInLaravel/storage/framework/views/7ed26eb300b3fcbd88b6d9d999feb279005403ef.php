
<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>
<h1>Home Pate</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\Laravel Project\kyamch\resources\views/home.blade.php ENDPATH**/ ?>