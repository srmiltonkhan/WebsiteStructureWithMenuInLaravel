
<?php $__env->startSection('titleKey','Home Page'); ?>
<?php $__env->startSection('buttonName','Submit Now'); ?>
<?php echo $__env->make('layout.MasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\Laravel Project\kyamch\resources\views/Home.blade.php ENDPATH**/ ?>