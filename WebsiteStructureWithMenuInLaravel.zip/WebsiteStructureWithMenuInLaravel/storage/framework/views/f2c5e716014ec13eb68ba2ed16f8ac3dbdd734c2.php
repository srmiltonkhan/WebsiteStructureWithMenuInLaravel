
<?php $__env->startSection('title','Portfolio'); ?>

<?php $__env->startSection('content'); ?>
<h1>Portfolio Pate</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\Laravel Project\kyamch\resources\views/portfolio.blade.php ENDPATH**/ ?>