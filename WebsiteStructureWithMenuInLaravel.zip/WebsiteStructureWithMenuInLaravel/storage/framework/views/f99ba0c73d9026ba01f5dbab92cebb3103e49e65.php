<h1><center>Contact Page</center></h>
<a href="<?php echo e(url('/')); ?>">Home</a>
<a href="<?php echo e(url('about')); ?>">About</a>
<a href="<?php echo e(url('contact')); ?>">Contact</a><?php /**PATH C:\Users\Administrator\Desktop\Laravel Project\kyamch\resources\views/ContactPage.blade.php ENDPATH**/ ?>