<div style="width: 100%; height: 100px; background-color: red">

</div><?php /**PATH C:\Users\Administrator\Desktop\Laravel Project\kyamch\resources\views/subview/Footer.blade.php ENDPATH**/ ?>